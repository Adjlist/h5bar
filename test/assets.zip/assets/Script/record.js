cc.Class({
extends: cc.Component, 
properties: {
     audioSource: {
         type: cc.AudioSource,
         default: null
     },
 },
 play: function () {
     this.audioSource.play();
 },
 pause: function () {
     this.audioSource.pause();
 },
onClick:function(){
        cc.director.loadScene("record")},
});